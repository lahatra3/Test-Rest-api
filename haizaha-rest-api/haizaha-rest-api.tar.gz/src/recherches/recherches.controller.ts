import { Controller } from '@nestjs/common';

@Controller('recherches')
export class RecherchesController {}
