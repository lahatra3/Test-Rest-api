export class CategoryDto {
    id: number;
    label: string;
}